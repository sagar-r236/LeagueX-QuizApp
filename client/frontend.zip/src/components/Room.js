const Room = () => {
    return (
        <>
        <h1>Room Component</h1>
        </>
    )
    
}

export default Room;