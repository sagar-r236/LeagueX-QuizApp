const Signup = () => {
    return <h1>Signup</h1>
}

export default Signup