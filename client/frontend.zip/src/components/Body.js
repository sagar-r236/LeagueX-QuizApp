import { useState } from "react";

const Body = () => {

    async function getProtected() {
        const data = await fetch('http://localhost:3000/protected');
        const json = await data.json();
        console.log(data)
        console.log(json)
    }

    useState(() => {
        getProtected()
    },[])

    return <h1>Body</h1>
}

export default Body;