const HeaderComponent = () => {
    return (
        <>
            <h1>League X Quiz</h1>
        
        </>
    )
}

export default HeaderComponent;